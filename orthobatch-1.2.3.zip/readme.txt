OrthoBatch by Day Lane (dayroselane.com/orthobatch)

A blender add-on for batch exporting orthographic renders of many model files in a local directory


---- LICENSE ----

OrthoBatch for Blender © 2024-2025 by Day Lane is licensed under CC BY-SA 4.0.

This license requires that reusers give credit to the creator. It allows reusers to distribute, remix, adapt, and build upon the material in any medium or format, even for commercial purposes. If others remix, adapt, or build upon the material, they must license the modified material under identical terms.

To view a copy of this license, visit https://creativecommons.org/licenses/by-sa/4.0/